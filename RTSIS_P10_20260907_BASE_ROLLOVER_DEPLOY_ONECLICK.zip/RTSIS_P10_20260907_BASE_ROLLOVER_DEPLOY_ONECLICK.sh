#!/usr/bin/env bash
set -euo pipefail

# ============================================================================
# RTSIS P10 Live Shadow — 2026-09-07 Certified Base Rollover + Deploy One-Click
# Version: 1.0.0
# Purpose:
#   1) Reuse the EXISTING rtsis-live-runtime repository and Cloudflare Worker.
#   2) Change ONLY the Certified base identity from 2026-09-04 -> 2026-09-07.
#   3) Preserve all Shadow-only governance boundaries.
#   4) Deploy with existing wrangler config / KV / cron / secrets.
#   5) Run pre-web / real-session gate without exposing READ_TOKEN.
#
# Idempotent:
#   - First run: patches exact old base identity, validates, deploys, runs gate.
#   - Later run: if already rolled over, skips patch/deploy and runs gate only.
#
# HARD BOUNDARIES:
#   NO model fit | NO ranking recompute | NO threshold retune | NO Production write
#   NO LATEST_CERTIFIED move | NO Frozen/Historical write | NO PageShare change
# ============================================================================

SCRIPT_VERSION="1.0.0"
OLD_ASOF="2026-09-04"
OLD_GEN="2026-09-04_da74c1422be6"
NEW_ASOF="2026-09-07"
NEW_GEN="2026-09-07_4aa727e32162"
NEW_UNIVERSE="1958"
EXPECTED_FRONT_CARDS="112"
WORKER_NAME="rtsis-p10-live-runtime-resilience-pilot-v0-1-0"
WORKER_URL="${P10_WORKER_URL:-https://rtsis-p10-live-runtime-resilience-pilot-v0-1-0.asurada3915.workers.dev}"
CONFIG="${P10_WRANGLER_CONFIG:-wrangler.jsonc}"
GATE="${P10_PRE_WEB_GATE_SCRIPT:-VERIFY_PRE_WEB_GATE.sh}"
TOKEN_FILE="${P10_READ_TOKEN_FILE:-.rtsis_p10_read_token.local}"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${P10_ROLLOVER_OUT_DIR:-P10_ROLLOVER_20260907_${RUN_ID}}"
REPORT="$OUT_DIR/P10_20260907_BASE_ROLLOVER_REPORT.json"
PATCH_REPORT="$OUT_DIR/patch_report.json"
DEPLOY_LOG="$OUT_DIR/wrangler_deploy.log"
DRYRUN_LOG="$OUT_DIR/wrangler_dryrun.log"
GATE_LOG="$OUT_DIR/pre_web_gate.log"
GATE_REPORT="$OUT_DIR/P10_PRE_WEB_GATE_REPORT.json"
ROOT_JSON="$OUT_DIR/worker_root.json"
SNAP_UNAUTH_BODY="$OUT_DIR/snapshot_unauthorized_body.txt"
mkdir -p "$OUT_DIR"

log(){ printf '%s\n' "$*"; }
fail(){
  local reason="$1"
  log ""
  log "FAIL_CLOSED: $reason"
  python3 - "$REPORT" "$reason" "$SCRIPT_VERSION" "$OLD_GEN" "$NEW_GEN" "$OUT_DIR" <<'PY'
import json,sys,datetime,os
p,reason,ver,oldg,newg,out=sys.argv[1:]
obj={
  "schema":"RTSIS_P10_20260907_BASE_ROLLOVER_REPORT_V1",
  "version":ver,
  "status":"FAIL_CLOSED",
  "reason":reason,
  "checked_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "old_generation_id":oldg,
  "target_generation_id":newg,
  "evidence_dir":out,
  "protected_surfaces":{
    "PageShare":"NO_CHANGE","Production":"NO_CHANGE","LATEST_CERTIFIED":"NO_CHANGE",
    "Frozen":"NO_CHANGE","Historical":"NO_CHANGE"
  }
}
os.makedirs(os.path.dirname(p),exist_ok=True)
open(p,'w').write(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
PY
  exit 1
}

sha256(){
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}';
  else shasum -a 256 "$1" | awk '{print $1}'; fi
}

log "================================================================"
log "RTSIS P10 2026-09-07 BASE ROLLOVER + DEPLOY ONE-CLICK v${SCRIPT_VERSION}"
log "Existing GitHub + Cloudflare runtime only｜NO PageShare change"
log "Target Certified base: ${NEW_GEN}｜universe=${NEW_UNIVERSE}"
log "================================================================"

# 0) Repository identity and required tools.
command -v git >/dev/null || fail "GIT_REQUIRED"
command -v python3 >/dev/null || fail "PYTHON3_REQUIRED"
command -v curl >/dev/null || fail "CURL_REQUIRED"
command -v npx >/dev/null || fail "NPX_REQUIRED"

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
[ -n "$ROOT" ] || fail "NOT_INSIDE_GIT_REPOSITORY"
cd "$ROOT"
REMOTE="$(git remote get-url origin 2>/dev/null || true)"
case "$REMOTE" in
  *asurada3915-cloud/rtsis-live-runtime* ) ;;
  * ) fail "WRONG_GIT_REPOSITORY::$REMOTE" ;;
esac
[ -f "$CONFIG" ] || fail "WRANGLER_CONFIG_MISSING::$CONFIG"
[ -f "$GATE" ] || fail "PRE_WEB_GATE_MISSING::$GATE"

# 1) Existing Cloudflare contract must remain intact.
grep -q '"name"[[:space:]]*:[[:space:]]*"rtsis-p10-live-runtime-resilience-pilot-v0-1-0"' "$CONFIG" || fail "WORKER_NAME_MISMATCH"
grep -q '"binding"[[:space:]]*:[[:space:]]*"P10_LIVE"' "$CONFIG" || fail "KV_BINDING_MISSING"
! grep -q 'REPLACE_WITH_PILOT_KV_NAMESPACE_ID' "$CONFIG" || fail "KV_PLACEHOLDER_NOT_REPLACED"
grep -Fq '"* 1-4 * * *"' "$CONFIG" || fail "CRON_0900_1259_MISSING"
grep -Fq '"0-35 5 * * *"' "$CONFIG" || fail "CRON_1300_1335_MISSING"

# 2) Secret presence only; NEVER print values.
[ -n "${CLOUDFLARE_API_TOKEN:-}" ] || fail "CLOUDFLARE_API_TOKEN_MISSING"
[ -f "$TOKEN_FILE" ] || fail "LOCAL_READ_TOKEN_FILE_MISSING::$TOKEN_FILE"
MODE="$(stat -c '%a' "$TOKEN_FILE" 2>/dev/null || stat -f '%Lp' "$TOKEN_FILE" 2>/dev/null || true)"
[ "$MODE" = "600" ] || fail "LOCAL_READ_TOKEN_FILE_MODE_NOT_600::$MODE"
READ_TOKEN_LEN="$(python3 - "$TOKEN_FILE" <<'PY'
import sys
print(len(open(sys.argv[1],'rb').read().strip()))
PY
)"
[ "$READ_TOKEN_LEN" -ge 32 ] || fail "LOCAL_READ_TOKEN_TOO_SHORT"

# 3) Discover executable/config files that contain the old/new base identities.
python3 - "$OLD_ASOF" "$OLD_GEN" "$NEW_ASOF" "$NEW_GEN" "$OUT_DIR/candidate_files.json" <<'PY'
import pathlib,sys,json
old_asof,old_gen,new_asof,new_gen,out=sys.argv[1:]
root=pathlib.Path('.')
allow={'.js','.mjs','.cjs','.ts','.tsx','.json','.jsonc','.sh','.py','.toml','.yaml','.yml'}
exclude_parts={'.git','node_modules','.wrangler','dist','build','.next'}
rows=[]
for p in root.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in allow: continue
    if any(part in exclude_parts for part in p.parts): continue
    # Ignore generated evidence/output folders.
    if any(part.startswith('P10_ROLLOVER_') for part in p.parts): continue
    try: s=p.read_text(encoding='utf-8')
    except Exception: continue
    og=s.count(old_gen); oa=s.count(old_asof); ng=s.count(new_gen); na=s.count(new_asof)
    if og or ng:
        rows.append({"path":str(p),"old_generation_hits":og,"old_asof_hits":oa,"new_generation_hits":ng,"new_asof_hits":na})
open(out,'w').write(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(rows,ensure_ascii=False,indent=2))
PY

OLD_HITS="$(python3 - "$OUT_DIR/candidate_files.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]));print(sum(r['old_generation_hits'] for r in x))
PY
)"
NEW_HITS="$(python3 - "$OUT_DIR/candidate_files.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]));print(sum(r['new_generation_hits'] for r in x))
PY
)"

ROLLOVER_PERFORMED=false
DEPLOY_PERFORMED=false

if [ "$OLD_HITS" -gt 0 ] && [ "$NEW_HITS" -gt 0 ]; then
  fail "MIXED_BASE_IDENTITIES_DETECTED__MANUAL_REVIEW_REQUIRED"
elif [ "$OLD_HITS" -gt 0 ]; then
  log "Base state: 9/4 detected -> controlled rollover required."

  # Require at least the authoritative gate to contain old base identity.
  grep -Fq "$OLD_GEN" "$GATE" || fail "AUTHORITATIVE_GATE_OLD_BASE_NOT_FOUND"

  # Create local rollback backup of ONLY files that will change.
  mkdir -p "$OUT_DIR/backup"
  python3 - "$OUT_DIR/candidate_files.json" "$OUT_DIR/backup" <<'PY'
import json,sys,pathlib,shutil
rows=json.load(open(sys.argv[1])); b=pathlib.Path(sys.argv[2])
for r in rows:
    if r['old_generation_hits']<=0: continue
    p=pathlib.Path(r['path']); q=b/p
    q.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,q)
PY

  # Exact identity patch only in files containing OLD_GEN.
  python3 - "$OUT_DIR/candidate_files.json" "$OLD_ASOF" "$OLD_GEN" "$NEW_ASOF" "$NEW_GEN" "$PATCH_REPORT" <<'PY'
import json,sys,pathlib,hashlib
cf,oa,og,na,ng,out=sys.argv[1:]
rows=json.load(open(cf)); changed=[]
for r in rows:
    if r['old_generation_hits']<=0: continue
    p=pathlib.Path(r['path']); before=p.read_bytes(); s=before.decode('utf-8')
    # Generation is the anchor. Date is changed only in the same file.
    s2=s.replace(og,ng).replace(oa,na)
    after=s2.encode('utf-8')
    if before==after: continue
    p.write_bytes(after)
    changed.append({
      'path':str(p),
      'before_sha256':hashlib.sha256(before).hexdigest(),
      'after_sha256':hashlib.sha256(after).hexdigest(),
      'old_generation_replacements':s.count(og),
      'old_asof_replacements':s.count(oa),
    })
open(out,'w').write(json.dumps({'changed_files':changed},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(changed,ensure_ascii=False,indent=2))
PY

  CHANGED_COUNT="$(python3 - "$PATCH_REPORT" <<'PY'
import json,sys;print(len(json.load(open(sys.argv[1]))['changed_files']))
PY
)"
  [ "$CHANGED_COUNT" -ge 1 ] || fail "NO_FILES_PATCHED"

  # Exact contract must now be new; old generation must be gone from executable/config files.
  grep -Fq "$NEW_GEN" "$GATE" || fail "GATE_NEW_BASE_NOT_INSTALLED"
  grep -Fq "'base_analysis_asof':'$NEW_ASOF'" "$GATE" || grep -Fq "\"base_analysis_asof\":\"$NEW_ASOF\"" "$GATE" || fail "GATE_NEW_ASOF_NOT_INSTALLED"

  LEFT_OLD="$(python3 - "$OLD_GEN" <<'PY'
import pathlib,sys
old=sys.argv[1];allow={'.js','.mjs','.cjs','.ts','.tsx','.json','.jsonc','.sh','.py','.toml','.yaml','.yml'}
exclude={'.git','node_modules','.wrangler','dist','build','.next'}; hits=[]
for p in pathlib.Path('.').rglob('*'):
 if not p.is_file() or p.suffix.lower() not in allow or any(x in exclude for x in p.parts) or any(x.startswith('P10_ROLLOVER_') for x in p.parts): continue
 try:s=p.read_text()
 except:continue
 if old in s:hits.append(str(p))
print('\n'.join(hits))
PY
)"
  [ -z "$LEFT_OLD" ] || fail "OLD_BASE_REMAINS::$LEFT_OLD"

  ROLLOVER_PERFORMED=true
else
  [ "$NEW_HITS" -gt 0 ] || fail "NEITHER_OLD_NOR_NEW_BASE_IDENTITY_FOUND"
  grep -Fq "$NEW_GEN" "$GATE" || fail "ALREADY_ROLLED_BUT_GATE_NOT_NEW_BASE"
  log "Base state: already 9/7 -> patch/deploy will be skipped; gate verification only."
fi

# 4) Static governance guard: required Shadow-only flags must still exist in gate.
for needle in \
  "'decision_effect':'NONE'" \
  "'ranking_recompute':False" \
  "'model_fit':False" \
  "'threshold_retune':False" \
  "'production_write':False" \
  "'latest_pointer_move':False" \
  "'auto_order':False"; do
  grep -Fq "$needle" "$GATE" || fail "GOVERNANCE_GUARD_MISSING::$needle"
done

# 5) If rollover happened, run Wrangler build/dry-run and deploy once.
if [ "$ROLLOVER_PERFORMED" = true ]; then
  log ""
  log "[1/4] Wrangler dry-run..."
  set +e
  npx wrangler deploy --dry-run --config "$CONFIG" >"$DRYRUN_LOG" 2>&1
  RC=$?
  set -e
  [ "$RC" -eq 0 ] || fail "WRANGLER_DRYRUN_FAILED__SEE::$DRYRUN_LOG"

  log "[2/4] Cloudflare deploy..."
  set +e
  npx wrangler deploy --config "$CONFIG" >"$DEPLOY_LOG" 2>&1
  RC=$?
  set -e
  [ "$RC" -eq 0 ] || fail "WRANGLER_DEPLOY_FAILED__SEE::$DEPLOY_LOG"
  DEPLOY_PERFORMED=true
else
  log ""
  log "[1/4] Already rolled over; skipping deploy."
fi

# 6) Independent remote root/auth checks. No secret is printed.
log "[3/4] Remote worker root + auth checks..."
ROOT_CODE="$(curl -sS -o "$ROOT_JSON" -w '%{http_code}' "$WORKER_URL/" || true)"
[ "$ROOT_CODE" = "200" ] || fail "WORKER_ROOT_HTTP_$ROOT_CODE"
python3 - "$ROOT_JSON" <<'PY' || fail "WORKER_ROOT_CONTRACT_FAIL"
import json,sys
x=json.load(open(sys.argv[1]))
assert x.get('build_id')=='P10_LIVE_RUNTIME_RESILIENCE_PILOT_V0_1_0'
assert x.get('scope')=='TRANSPORT_AND_RUNTIME_RESILIENCE_ONLY'
assert x.get('production') is False
assert x.get('decision_effect')=='NONE'
PY
UNAUTH_CODE="$(curl -sS -o "$SNAP_UNAUTH_BODY" -w '%{http_code}' "$WORKER_URL/snapshot" || true)"
[ "$UNAUTH_CODE" = "401" ] || fail "SNAPSHOT_UNAUTH_GATE_BAD_HTTP_$UNAUTH_CODE"

# 7) Run the repository's authoritative pre-web / real-session gate.
#    The gate has just been rolled to NEW_GEN. Before the first new scheduled tick,
#    an old KV snapshot may still exist; in that case we preserve fail-closed and
#    report WAITING_FIRST_9_7_BASE_TICK rather than pretending web-ready.
log "[4/4] Authoritative pre-web / real-session gate..."
set +e
P10_GATE_REPORT="$GATE_REPORT" bash "$GATE" >"$GATE_LOG" 2>&1
GATE_RC=$?
set -e

FINAL_STATUS=""
FINAL_REASON=""
WEB_READY=false

if [ -f "$GATE_REPORT" ]; then
  GATE_STATUS="$(python3 - "$GATE_REPORT" <<'PY'
import json,sys
try: print(json.load(open(sys.argv[1])).get('status',''))
except: print('')
PY
)"
  GATE_REASON="$(python3 - "$GATE_REPORT" <<'PY'
import json,sys
try: print(json.load(open(sys.argv[1])).get('reason',''))
except: print('')
PY
)"
else
  GATE_STATUS=""
  GATE_REASON=""
fi

case "$GATE_STATUS" in
  PASS_REAL_SESSION__READY_FOR_WEB_INTEGRATION)
    FINAL_STATUS="PASS_P10_20260907_BASE_ROLLOVER_DEPLOY__REAL_SESSION_READY"
    FINAL_REASON="NEW_BASE_AND_REAL_SESSION_GATE_PASS"
    WEB_READY=true
    ;;
  PASS_PRE_WEB_INFRA_READY__WAITING_REAL_SESSION|WAITING_REAL_SESSION_HEALTHY_GATE)
    FINAL_STATUS="PASS_P10_20260907_BASE_ROLLOVER_DEPLOY__WAITING_REAL_SESSION"
    FINAL_REASON="$GATE_STATUS"
    ;;
  FAIL_CLOSED)
    # If deploy was successful but the only failure is a stale OLD_GEN snapshot left in KV,
    # do not synthesize/overwrite it. Wait for the first real scheduled tick.
    if grep -Fq "base_generation_id='$OLD_GEN' expected '$NEW_GEN'" "$GATE_LOG" 2>/dev/null || \
       grep -Fq "base_generation_id=\"$OLD_GEN\" expected \"$NEW_GEN\"" "$GATE_LOG" 2>/dev/null || \
       grep -Fq "$OLD_GEN" "$GATE_LOG" 2>/dev/null; then
      FINAL_STATUS="PASS_P10_20260907_BASE_ROLLOVER_DEPLOY__WAITING_FIRST_NEW_BASE_TICK"
      FINAL_REASON="OLD_KV_SNAPSHOT_PRESERVED_UNTIL_NEXT_REAL_SCHEDULED_TICK"
    else
      fail "AUTHORITATIVE_GATE_FAIL_CLOSED__SEE::$GATE_LOG"
    fi
    ;;
  *)
    if [ "$GATE_RC" -eq 0 ]; then
      FINAL_STATUS="PASS_P10_20260907_BASE_ROLLOVER_DEPLOY__WAITING_REAL_SESSION"
      FINAL_REASON="GATE_EXIT_ZERO::$GATE_STATUS"
    else
      fail "GATE_UNCLASSIFIED_FAILURE_RC_${GATE_RC}__SEE::$GATE_LOG"
    fi
    ;;
esac

# 8) Evidence / final report. Never include token contents.
python3 - "$REPORT" "$FINAL_STATUS" "$FINAL_REASON" "$SCRIPT_VERSION" "$REMOTE" "$WORKER_URL" "$OLD_GEN" "$NEW_GEN" "$NEW_ASOF" "$NEW_UNIVERSE" "$ROLLOVER_PERFORMED" "$DEPLOY_PERFORMED" "$WEB_READY" "$GATE_STATUS" "$OUT_DIR" <<'PY'
import json,sys,datetime,os,hashlib,pathlib
(p,status,reason,ver,remote,url,oldg,newg,asof,univ,rolled,deployed,webready,gate,out)=sys.argv[1:]
def sha(path):
    q=pathlib.Path(path)
    return hashlib.sha256(q.read_bytes()).hexdigest() if q.exists() else None
obj={
 "schema":"RTSIS_P10_20260907_BASE_ROLLOVER_REPORT_V1",
 "version":ver,
 "status":status,
 "reason":reason,
 "checked_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
 "repository_remote":remote,
 "worker_url":url,
 "target":{"base_analysis_asof":asof,"base_generation_id":newg,"universe":int(univ)},
 "prior":{"base_generation_id":oldg},
 "rollover_performed":rolled=='true',
 "deploy_performed":deployed=='true',
 "authoritative_gate_status":gate,
 "web_integration_authorized":webready=='true',
 "evidence":{
   "patch_report_sha256":sha(os.path.join(out,'patch_report.json')),
   "gate_report_sha256":sha(os.path.join(out,'P10_PRE_WEB_GATE_REPORT.json')),
   "worker_root_sha256":sha(os.path.join(out,'worker_root.json')),
 },
 "protected_surfaces":{
   "PageShare":"NO_CHANGE","Production":"NO_CHANGE","LATEST_CERTIFIED":"NO_CHANGE",
   "Frozen":"NO_CHANGE","Historical":"NO_CHANGE"
 },
 "governance":{
   "decision_effect":"NONE","ranking_recompute":False,"model_fit":False,
   "threshold_retune":False,"production_write":False,"latest_pointer_move":False,"auto_order":False
 }
}
open(p,'w').write(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
PY

# Optional evidence zip if zip is available.
if command -v zip >/dev/null 2>&1; then
  ZIP_NAME="RTSIS_P10_20260907_BASE_ROLLOVER_EVIDENCE_${RUN_ID}.zip"
  (cd "$OUT_DIR" && zip -qr "../$ZIP_NAME" .)
  log "Evidence ZIP: $ZIP_NAME"
fi

log ""
log "================================================================"
log "$FINAL_STATUS"
log "Reason: $FINAL_REASON"
log "Target base: $NEW_GEN"
log "PageShare: NO_CHANGE"
log "Production/LATEST/Frozen/Historical: NO_CHANGE"
log "Report: $REPORT"
log "================================================================"

if [ "$WEB_READY" = true ]; then
  log "REAL SESSION PASS: ready for the separate Web Adapter + PageShare release gate."
else
  log "Not web-ready yet. Re-run THIS SAME SCRIPT after the first healthy 09:00+ scheduled tick."
fi
